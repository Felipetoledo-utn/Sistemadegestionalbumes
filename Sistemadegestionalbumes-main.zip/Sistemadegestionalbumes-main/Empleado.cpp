#include <iostream>
#include <cstring>
#include "Empleado.h"
using namespace std;

Empleado::Empleado() {
    _DNI = 0;
    strncpy(_Nombre, "Sin nombre", sizeof(_Nombre));
    strncpy(_Apellido, "Sin apellido", sizeof(_Apellido));
    _Telefono = 0;
    strncpy(_Mail, "Sin mail", sizeof(_Mail));
    _Sueldo = 0.0;
    strncpy(_FechaIngreso, "Fecha no especificada", sizeof(_FechaIngreso));
}

void Empleado::setDNI(int dni) {
    _DNI = dni;
}

void Empleado::setNombre(string nombre) {
    strncpy(_Nombre, nombre.c_str(), sizeof(_Nombre));
}

void Empleado::setApellido(string apellido) {
    strncpy(_Apellido, apellido.c_str(), sizeof(_Apellido));
}

void Empleado::setTelefono(int telefono) {
    _Telefono = telefono;
}

void Empleado::setMail(string mail) {
    strncpy(_Mail, mail.c_str(), sizeof(_Mail));
}

void Empleado::setSueldo(float sueldo) {
    _Sueldo = sueldo;
}

void Empleado::setFechaIngreso(string fecha) {
    strncpy(_FechaIngreso, fecha.c_str(), sizeof(_FechaIngreso));
}

int Empleado::getDNI() {
    return _DNI;
}

string Empleado::getNombre() {
    return string(_Nombre);
}

string Empleado::getApellido() {
    return string(_Apellido);
}

int Empleado::getTelefono() {
    return _Telefono;
}

string Empleado::getMail() {
    return string(_Mail);
}

float Empleado::getSueldo() {
    return _Sueldo;
}

string Empleado::getFechaIngreso() {
    return string(_FechaIngreso);
}

void Empleado::cargar() {
    cout << "Ingrese el DNI: ";
    cin >> _DNI;
    cin.ignore();
    cout << "Ingrese el nombre: ";
    cin.getline(_Nombre, 50);
    cout << "Ingrese el apellido: ";
    cin.getline(_Apellido, 50);
    cout << "Ingrese el tel�fono: ";
    cin >> _Telefono;
    cin.ignore();
    cout << "Ingrese el mail: ";
    cin.getline(_Mail, 100);
    cout << "Ingrese el sueldo: ";
    cin >> _Sueldo;
    cin.ignore();
    cout << "Ingrese la fecha de ingreso: ";
    cin.getline(_FechaIngreso, 50);
}

void Empleado::mostrar() {
    cout << "DNI: " << _DNI << endl;
    cout << "Nombre: " << _Nombre << endl;
    cout << "Apellido: " << _Apellido << endl;
    cout << "Tel�fono: " << _Telefono << endl;
    cout << "Mail: " << _Mail << endl;
    cout << "Sueldo: " << _Sueldo << endl;
    cout << "Fecha de Ingreso: " << _FechaIngreso << endl;
}
