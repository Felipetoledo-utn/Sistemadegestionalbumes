#include <iostream>
#include <cstring>
#include "Artista.h"
using namespace std;

Artista::Artista() {
    strncpy(_Nombre, "Sin nombre", sizeof(_Nombre));
    strncpy(_Genero, "Sin genero", sizeof(_Genero));
    strncpy(_Nacion, "Sin nacion", sizeof(_Nacion));
    _Anio = 0;
    _Albumes = 0;
}

void Artista::setNombre(string nombre) {
    strncpy(_Nombre, nombre.c_str(), sizeof(_Nombre));
}

void Artista::setGenero(string genero) {
    strncpy(_Genero, genero.c_str(), sizeof(_Genero));
}

void Artista::setNacion(string nacion) {
    strncpy(_Nacion, nacion.c_str(), sizeof(_Nacion));
}

void Artista::setAnio(int anio) {
    _Anio = anio;
}

void Artista::setAlbumes(int albumes) {
    _Albumes = albumes;
}

string Artista::getNombre() {
    return string(_Nombre);
}

string Artista::getGenero() {
    return string(_Genero);
}

string Artista::getNacion() {
    return string(_Nacion);
}

int Artista::getAnio() {
    return _Anio;
}

int Artista::getAlbumes() {
    return _Albumes;
}

void Artista::cargar() {
    cout << "Ingrese el nombre del artista: ";
    cin.getline(_Nombre, 50);
    cout << "Ingrese el g�nero: ";
    cin.getline(_Genero, 50);
    cout << "Ingrese la naci�n: ";
    cin.getline(_Nacion, 50);
    cout << "Ingrese el a�o: ";
    cin >> _Anio;
    cout << "Ingrese el n�mero de �lbumes: ";
    cin >> _Albumes;
}

void Artista::mostrar() {
    cout << "Nombre: " << _Nombre << endl;
    cout << "Genero: " << _Genero << endl;
    cout << "Nacion: " << _Nacion << endl;
    cout << "Anio: " << _Anio << endl;
    cout << "Albumes: " << _Albumes << endl;
}
