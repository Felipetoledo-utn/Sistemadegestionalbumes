#ifndef FECHA_H
#define FECHA_H

#include <string>
using namespace std;

class Fecha {
    public:
        Fecha();
        Fecha(int anio, int mes, int dia);
        int getAnio();
        int getMes();
        int getDia();
        string getFecha();
        void setAnio(int anio);
        void setMes(int mes);
        void setDia(int dia);
        void setFecha();
    private:
        int _Anio;
        int _Mes;
        int _Dia;
        string _Fecha;
};

#endif // FECHA_H

