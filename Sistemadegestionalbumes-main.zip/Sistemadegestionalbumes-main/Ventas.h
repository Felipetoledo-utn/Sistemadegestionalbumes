#ifndef VENTAS_H
#define VENTAS_H

#include <string>
using namespace std;

class Ventas {
    public:
        Ventas();
        void setAlbum(string album);
        void setImporte(float imp);
        void setEmp(string emp);
        void setCliente(string cliente);
        void setFecha(string fecha);
        string getAlbum();
        float getImporte();
        string getEmp();
        string getCliente();
        string getFecha();
        void cargar();
        void mostrar();

    private:
        char _Album[50];
        float _Importe;
        char _Empleado[50];
        char _Cliente[50];
        char _FechaVenta[50];
};

#endif
