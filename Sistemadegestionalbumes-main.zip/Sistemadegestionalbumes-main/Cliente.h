#ifndef CLIENTE_H
#define CLIENTE_H

#include <string>
using namespace std;

class Cliente {
    public:
        Cliente();
        void setDNI(int dni);
        void setNombre(string nombre);
        void setApellido(string apellido);
        void setTelefono(int telefono);
        void setMail(string mail);
        void setFechaNacimiento(string fecha);
        int getDNI();
        string getNombre();
        string getApellido();
        int getTelefono();
        string getMail();
        string getFechaNacimiento();
        void cargar();
        void mostrar();

    private:
        int _DNI;
        char _Nombre[50];
        char _Apellido[50];
        int _Telefono;
        char _Mail[100];
        char _FechaNacimiento[20];
};

#endif // CLIENTE_H
