#ifndef ALBUM_H
#define ALBUM_H

#include <string>
using namespace std;

class Album {
    public:
        Album();
        Album(string nombre, string genero, string artista, int anio, float precio);
        void setNombre(string nombre);
        void setGenero(string genero);
        void setArtista(string artista);
        void setAnio(int anio);
        void setPrecio(float precio);
        string getNombre();
        string getGenero();
        string getArtista();
        int getAnio();
        float getPrecio();
        string ToString();

    private:
        char _Nombre[50];
        char _Genero[50];
        char _Artista[50];
        int _Anio;
        float _Precio;
};

#endif // ALBUM_H
