#ifndef CANCION_H
#define CANCION_H

#include <string>
using namespace std;

class Cancion
{
    public:
        Cancion();
        void setNombre(string nom);
        void setArtista(string art);
        void setGenero(string gen);
        void setTiempo(float tiempo);
        void setAnio(int anio);
        string GetNombre();
        string GetArtista();
        string GetGenero();
        float GetTiempo();
        int GetAnio();
        string ToString();
    private:
        char _Nombre[50];
        char _Artista[50];
        char _Genero [50];
        float _Tiempo;
        int _Anio;

};

#endif // CANCION_H
