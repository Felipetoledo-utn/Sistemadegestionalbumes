#ifndef ARTISTA_H
#define ARTISTA_H

#include <string>
using namespace std;

class Artista {
    public:
        Artista();
        void setNombre(string nombre);
        void setGenero(string genero);
        void setNacion(string nacion);
        void setAnio(int anio);
        void setAlbumes(int albumes);
        string getNombre();
        string getGenero();
        string getNacion();
        int getAnio();
        int getAlbumes();
        void cargar();
        void mostrar();

    private:
        char _Nombre[50];
        char _Genero[50];
        char _Nacion[50];
        int _Anio;
        int _Albumes;
};

#endif // ARTISTA_H
