#include <iostream>
#include "Fecha.h"
using namespace std;

Fecha::Fecha() {
    _Anio = 0;
    _Mes = 0;
    _Dia = 0;
    _Fecha = "Fecha no especificada";
}

Fecha::Fecha(int anio, int mes, int dia) {
    _Anio = anio;
    _Mes = mes;
    _Dia = dia;
    setFecha();
}

int Fecha::getAnio() {
    return _Anio;
}

int Fecha::getMes() {
    return _Mes;
}

int Fecha::getDia() {
    return _Dia;
}

string Fecha::getFecha() {
    return _Fecha;
}

void Fecha::setAnio(int anio) {
    _Anio = anio;
    setFecha();
}

void Fecha::setMes(int mes) {
    _Mes = mes;
    setFecha();
}

void Fecha::setDia(int dia) {
    _Dia = dia;
    setFecha();
}

void Fecha::setFecha() {
    _Fecha = to_string(_Dia) + "/" + to_string(_Mes) + "/" + to_string(_Anio);
}

