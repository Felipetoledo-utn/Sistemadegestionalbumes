#include <iostream>
#include <cstring>
#include "Album.h"
using namespace std;

Album::Album() {
    strncpy(_Nombre, "Sin nombre", sizeof(_Nombre));
    strncpy(_Genero, "Sin genero", sizeof(_Genero));
    strncpy(_Artista, "Artista no encontrado", sizeof(_Artista));
    _Anio = 0;
    _Precio = 0.0;
}

void Album::setNombre(string nombre) {
    strncpy(_Nombre, nombre.c_str(), sizeof(_Nombre));
}

void Album::setGenero(string genero) {
    strncpy(_Genero, genero.c_str(), sizeof(_Genero));
}

void Album::setArtista(string artista) {
    strncpy(_Artista, artista.c_str(), sizeof(_Artista));
}

void Album::setAnio(int anio) {
    _Anio = anio;
}

void Album::setPrecio(float precio) {
    _Precio = precio;
}

string Album::getNombre() {
    return string(_Nombre);
}

string Album::getGenero() {
    return string(_Genero);
}

string Album::getArtista() {
    return string(_Artista);
}

int Album::getAnio() {
    return _Anio;
}

float Album::getPrecio() {
    return _Precio;
}

void Album::cargar() {
    cout << "Ingrese el nombre del �lbum: ";
    cin.getline(_Nombre, 50);
    cout << "Ingrese el g�nero: ";
    cin.getline(_Genero, 50);
    cout << "Ingrese el artista: ";
    cin.getline(_Artista, 50);
    cout << "Ingrese el a�o: ";
    cin >> _Anio;
    cout << "Ingrese el precio: ";
    cin >> _Precio;
}

void Album::mostrar() {
    cout << "Nombre: " << _Nombre << endl;
    cout << "Genero: " << _Genero << endl;
    cout << "Artista: " << _Artista << endl;
    cout << "Anio: " << _Anio << endl;
    cout << "Precio: " << _Precio << endl;
}
