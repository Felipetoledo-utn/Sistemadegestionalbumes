#include <iostream>
#include <cstring>
#include "Cancion.h"
using namespace std;

Cancion::Cancion() {
    strncpy(_Nombre, "Sin nombre", sizeof(_Nombre));
    strncpy(_Artista, "Sin artista", sizeof(_Artista));
    strncpy(_Genero, "Sin genero", sizeof(_Genero));
    _Tiempo = 0;
    _Anio = 0;
}

void Cancion::setNombre(string nom) {
    strncpy(_Nombre, nom.c_str(), sizeof(_Nombre));
}

void Cancion::setArtista(string art) {
    strncpy(_Artista, art.c_str(), sizeof(_Artista));
}

void Cancion::setGenero(string gen) {
    strncpy(_Genero, gen.c_str(), sizeof(_Genero));
}

void Cancion::setTiempo(float tiempo) {
    _Tiempo = tiempo;
}

void Cancion::setAnio(int anio) {
    _Anio = anio;
}

string Cancion::getNombre() {
    return string(_Nombre);
}

string Cancion::getArtista() {
    return string(_Artista);
}

string Cancion::getGenero() {
    return string(_Genero);
}

float Cancion::getTiempo() {
    return _Tiempo;
}

int Cancion::getAnio() {
    return _Anio;
}

void Cancion::cargar() {
    cout << "Ingrese el nombre de la canci�n: ";
    cin.getline(_Nombre, 50);
    cout << "Ingrese el artista: ";
    cin.getline(_Artista, 50);
    cout << "Ingrese el g�nero: ";
    cin.getline(_Genero, 50);
    cout << "Ingrese el tiempo: ";
    cin >> _Tiempo;
    cout << "Ingrese el a�o: ";
    cin >> _Anio;
}

void Cancion::mostrar() {
    cout << "Nombre: " << _Nombre << endl;
    cout << "Artista: " << _Artista << endl;
    cout << "Genero: " << _Genero << endl;
    cout << "Tiempo: " << _Tiempo << endl;
    cout << "Anio: " << _Anio << endl;
}
