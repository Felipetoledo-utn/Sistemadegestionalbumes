#ifndef EMPLEADO_H
#define EMPLEADO_H

#include <string>
using namespace std;

class Empleado {
    public:
        Empleado();
        void setDNI(int dni);
        void setNombre(string nombre);
        void setApellido(string apellido);
        void setTelefono(int telefono);
        void setMail(string mail);
        void setSueldo(float sueldo);
        void setFechaIngreso(string fecha);
        int getDNI();
        string getNombre();
        string getApellido();
        int getTelefono();
        string getMail();
        float getSueldo();
        string getFechaIngreso();
        void cargar();
        void mostrar();

    private:
        int _DNI;
        char _Nombre[50];
        char _Apellido[50];
        int _Telefono;
        char _Mail[100];
        float _Sueldo;
        char _FechaIngreso[50];
};

#endif
