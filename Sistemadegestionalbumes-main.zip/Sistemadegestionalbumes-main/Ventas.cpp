#include <iostream>
#include <cstring>
#include "Ventas.h"
using namespace std;

Ventas::Ventas() {
    strncpy(_Album, "No se vendio ningun album", sizeof(_Album));
    _Importe = 0.0;
    strncpy(_Empleado, "Empleado no encontrado", sizeof(_Empleado));
    strncpy(_Cliente, "Cliente no encontrado", sizeof(_Cliente));
    strncpy(_FechaVenta, "Fecha no especificada", sizeof(_FechaVenta));
}

void Ventas::setAlbum(string album) {
    strncpy(_Album, album.c_str(), sizeof(_Album));
}

void Ventas::setImporte(float imp) {
    _Importe = imp;
}

void Ventas::setEmp(string emp) {
    strncpy(_Empleado, emp.c_str(), sizeof(_Empleado));
}

void Ventas::setCliente(string cliente) {
    strncpy(_Cliente, cliente.c_str(), sizeof(_Cliente));
}

void Ventas::setFecha(string fecha) {
    strncpy(_FechaVenta, fecha.c_str(), sizeof(_FechaVenta));
}

string Ventas::getAlbum() {
    return string(_Album);
}

float Ventas::getImporte() {
    return _Importe;
}

string Ventas::getEmp() {
    return string(_Empleado);
}

string Ventas::getCliente() {
    return string(_Cliente);
}

string Ventas::getFecha() {
    return string(_FechaVenta);
}

void Ventas::cargar() {
    cout << "Ingrese el nombre del �lbum: ";
    cin.getline(_Album, 50);
    cout << "Ingrese el importe: ";
    cin >> _Importe;
    cin.ignore();
    cout << "Ingrese el nombre del empleado: ";
    cin.getline(_Empleado, 50);
    cout << "Ingrese el nombre del cliente: ";
    cin.getline(_Cliente, 50);
    cout << "Ingrese la fecha de venta: ";
    cin.getline(_FechaVenta, 50);
}

void Ventas::mostrar() {
    cout << "Album: " << _Album << endl;
    cout << "Importe: " << _Importe << endl;
    cout << "Empleado: " << _Empleado << endl;
    cout << "Cliente: " << _Cliente << endl;
    cout << "Fecha de venta: " << _FechaVenta << endl;
}
