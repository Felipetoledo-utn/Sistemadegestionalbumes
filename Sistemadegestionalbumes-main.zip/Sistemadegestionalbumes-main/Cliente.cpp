#include <iostream>
#include <cstring>
#include "Cliente.h"
using namespace std;

Cliente::Cliente() {
    _DNI = 0;
    strncpy(_Nombre, "Sin Nombre", sizeof(_Nombre));
    strncpy(_Apellido, "Sin Apellido", sizeof(_Apellido));
    _Telefono = 0;
    strncpy(_Mail, "Sin Mail", sizeof(_Mail));
    strncpy(_FechaNacimiento, "Fecha no especificada", sizeof(_FechaNacimiento));
}

void Cliente::setDNI(int dni) {
    _DNI = dni;
}

void Cliente::setNombre(string nombre) {
    strncpy(_Nombre, nombre.c_str(), sizeof(_Nombre));
}

void Cliente::setApellido(string apellido) {
    strncpy(_Apellido, apellido.c_str(), sizeof(_Apellido));
}

void Cliente::setTelefono(int telefono) {
    _Telefono = telefono;
}

void Cliente::setMail(string mail) {
    strncpy(_Mail, mail.c_str(), sizeof(_Mail));
}

void Cliente::setFechaNacimiento(string fecha) {
    strncpy(_FechaNacimiento, fecha.c_str(), sizeof(_FechaNacimiento));
}

int Cliente::getDNI() {
    return _DNI;
}

string Cliente::getNombre() {
    return string(_Nombre);
}

string Cliente::getApellido() {
    return string(_Apellido);
}

int Cliente::getTelefono() {
    return _Telefono;
}

string Cliente::getMail() {
    return string(_Mail);
}

string Cliente::getFechaNacimiento() {
    return string(_FechaNacimiento);
}

void Cliente::cargar() {
    cout << "Ingrese el DNI: ";
    cin >> _DNI;
    cin.ignore();
    cout << "Ingrese el nombre: ";
    cin.getline(_Nombre, 50);
    cout << "Ingrese el apellido: ";
    cin.getline(_Apellido, 50);
    cout << "Ingrese el tel�fono: ";
    cin >> _Telefono;
    cin.ignore();
    cout << "Ingrese el mail: ";
    cin.getline(_Mail, 100);
    cout << "Ingrese la fecha de nacimiento: ";
    cin.getline(_FechaNacimiento, 20);
}

void Cliente::mostrar() {
    cout << "DNI: " << _DNI << endl;
    cout << "Nombre: " << _Nombre << endl;
    cout << "Apellido: " << _Apellido << endl;
    cout << "Telefono: " << _Telefono << endl;
    cout << "Mail: " << _Mail << endl;
    cout << "Fecha de Nacimiento: " << _FechaNacimiento << endl;
}
